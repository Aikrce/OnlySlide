# CoreDataModule 迁移框架

## 概述

CoreDataModule 迁移框架是 OnlySlide 项目的一个核心组件，用于处理 CoreData 数据模型的版本升级和数据迁移。该框架提供了自动化的迁移流程，支持从任意版本迁移到最新版本，同时提供友好的用户界面展示迁移进度。

## 资源管理系统

框架包含一个强大的资源管理系统，通过 `CoreDataResourceManager` 集中管理所有 Core Data 相关资源：

### CoreDataResourceManager 特性

- **多 Bundle 资源加载**：自动搜索并从多个 Bundle 加载模型资源，适用于模块化架构
- **健壮的模型查找**：能够处理各种命名模式和位置的模型文件
- **版本模型管理**：优化的版本模型获取和管理机制
- **备份系统**：内置备份创建和管理功能，支持定期清理过期备份
- **线程安全访问**：通过 `@MainActor` 标记确保资源访问的线程安全
- **错误处理**：提供清晰的错误报告和恢复建议

### 使用示例

```swift
// 获取资源管理器实例
let resourceManager = CoreDataResourceManager.shared

// 获取合并的对象模型
if let model = resourceManager.mergedObjectModel() {
    // 使用模型...
}

// 获取模型版本
let allVersions = resourceManager.availableModelVersions()

// 备份管理
let backupURL = resourceManager.backupStoreURL()
resourceManager.cleanupBackups(keepLatest: 5)
```

## 主要特性

- **自动迁移检测**：在应用启动时自动检测是否需要迁移
- **渐进式迁移**：支持多个版本间的渐进式迁移
- **映射模型管理**：内置映射模型查找器，支持自定义映射模型
- **备份与恢复**：迁移前自动备份，失败时自动恢复
- **SwiftUI 集成**：提供现代 SwiftUI 界面展示迁移进度
- **测试支持**：完整的测试套件确保迁移功能正常工作
- **自定义策略**：支持实体级别的自定义迁移策略
- **并发安全**：使用 Swift 并发特性和 Sendable 协议确保线程安全

## 架构

迁移框架由以下主要组件组成：

1. **CoreDataResourceManager**：统一管理 Core Data 资源，支持多 Bundle 资源加载
2. **CoreDataModelVersionManager**：管理模型版本，检测是否需要迁移
3. **CoreDataMigrationManager**：执行迁移操作，处理备份和恢复
4. **MappingModelFinder**：查找适用的映射模型，支持自定义映射模型
5. **CustomEntityMigrationPolicies**：实体级别的自定义迁移策略
6. **MigrationStartupHandler**：应用启动时的迁移入口点
7. **MigrationProgressView**：显示迁移进度的 SwiftUI 视图

## 使用方法

### 基本用法

在应用入口点（如 SwiftUI 应用的 `App` 结构体）中集成迁移框架：

```swift
import SwiftUI
import CoreDataModule

@main
struct MyApp: App {
    @StateObject private var migrationManager = MigrationManager()
    
    var body: some Scene {
        WindowGroup {
            MigrationProgressView(migrationManager: migrationManager) {
                ContentView()  // 迁移完成后显示的主内容视图
            }
        }
    }
}
```

这将在应用启动时自动检查是否需要迁移，并在需要时执行迁移操作。迁移过程中会显示进度界面，迁移完成后自动切换到主内容视图。

### 自定义存储位置

如果您的 CoreData 存储不在默认位置，可以指定存储 URL：

```swift
migrationManager.checkAndMigrateStoreIfNeeded(at: customStoreURL)
```

### 监听迁移状态

您可以观察 `MigrationManager` 的状态变化：

```swift
migrationManager.$status.sink { status in
    switch status {
    case .inProgress:
        print("迁移正在进行中")
    case .completed:
        print("迁移已完成")
    case .failed(let error):
        print("迁移失败: \(error.localizedDescription)")
    }
}
```

## 添加新的模型版本

当您需要更新数据模型时，请按照以下步骤操作：

1. 在 Xcode 中添加新的模型版本：
   - 选择 .xcdatamodeld 文件
   - Editor -> Add Model Version...
   - 命名为有意义的名称（如 "ModelV2"）

2. 更新 `ModelVersion` 结构体，与新版本兼容：

```swift
// ModelVersion 是一个结构体，表示模型版本信息
public struct ModelVersion: Comparable, Sendable {
    public let major: Int
    public let minor: Int
    public let patch: Int
    public let identifier: String
    
    // 从版本字符串初始化
    public init?(versionString: String) {
        // 解析版本号，例如 "V1_2_3"
    }
    
    // 从版本标识符集合初始化
    public init?(versionIdentifiers: Set<String>) {
        // 查找并解析版本标识符
    }
}
```

3. 如果需要自定义迁移逻辑，创建映射模型和自定义策略类。

## 创建自定义映射模型

对于复杂的模型变更（如实体重命名、属性类型变更等），需要创建自定义映射模型：

1. 创建 `.xcmappingmodel` 文件：
   - File -> New -> File... -> Core Data -> Mapping Model
   - 选择源模型和目标模型
   - 命名为 `Mapping_[Source]_to_[Destination].xcmappingmodel`

2. 配置实体映射：
   - 设置正确的映射类型（Copy, Transform, Add, Remove）
   - 配置属性映射
   - 如果需要，指定自定义实体迁移策略类

3. 创建自定义实体迁移策略类：

```swift
import Foundation
import CoreData

public final class MyEntityMigrationPolicy: NSEntityMigrationPolicy {
    override public func createDestinationInstances(
        forSource sInstance: NSManagedObject,
        in mapping: NSEntityMapping,
        manager: NSMigrationManager
    ) throws {
        // 调用父类方法创建基本实例
        try super.createDestinationInstances(forSource: sInstance, in: mapping, manager: manager)
        
        // 获取目标实例
        guard let dInstance = manager.destinationInstances(
            forEntityMappingName: mapping.name,
            sourceInstances: [sInstance]
        ).first else {
            throw NSError(domain: "MigrationError", code: 1, userInfo: nil)
        }
        
        // 执行自定义迁移逻辑
        // ...
    }
}
```

4. 将自定义策略类添加到映射模型中：
   - 在 Xcode 的映射模型编辑器中，选择实体映射
   - 在 Inspector 面板中，设置 "Custom Policy" 为您的策略类名

## 测试迁移

框架提供了测试套件来验证迁移功能。您可以扩展测试套件来测试新的版本迁移：

```swift
func testMigrationFromVersion2ToVersion3() async throws {
    // 创建版本2的测试存储
    try createAndPopulateTestStore(
        version: .version2,
        at: tempStoreURL
    )
    
    // 执行迁移
    let didMigrate = try await migrationManager.performMigration(
        at: tempStoreURL
    )
    
    XCTAssertTrue(didMigrate, "迁移应该成功执行")
    
    // 验证迁移结果
    // ...
}
```

## 资源管理器测试

可以使用集成测试来验证资源管理器的功能：

```swift
class ResourceManagerIntegrationTests: XCTestCase {
    var resourceManager: CoreDataResourceManager!
    
    override func setUpWithError() throws {
        resourceManager = CoreDataResourceManager()
    }
    
    func testModelLoading() {
        // 测试模型加载
        let model = resourceManager.mergedObjectModel()
        XCTAssertNotNil(model)
        
        // 测试所有版本加载
        let versions = resourceManager.availableModelVersions()
        XCTAssertFalse(versions.isEmpty)
    }
    
    func testBackupManagement() throws {
        // 创建备份
        let backupURL = resourceManager.backupStoreURL()
        
        // 测试清理
        resourceManager.cleanupBackups(keepLatest: 3)
        let backups = resourceManager.allBackups()
        
        XCTAssertLessThanOrEqual(backups.count, 3)
    }
}
```

## 疑难解答

### 常见问题

1. **错误: "无法找到从版本X到版本Y的映射模型"**
   - 确保已创建并添加正确命名的映射模型文件
   - 验证映射模型中的实体和属性映射配置是否正确
   - 检查 Bundle 资源加载配置是否正确

2. **错误: "迁移操作无法完成"**
   - 检查自定义迁移策略类中是否有逻辑错误
   - 确保数据库文件未损坏
   - 查看备份目录是否存在可恢复的备份

3. **警告: "自动推断的映射模型可能不准确"**
   - 对于复杂变更，应创建自定义映射模型而非依赖自动推断

4. **错误: "无法加载模型资源"**
   - 使用 CoreDataResourceManager 提供的多 Bundle 搜索功能
   - 确保模型文件已正确添加到目标 Bundle
   - 检查模型文件命名是否符合预期格式

### 并发安全注意事项

1. 所有单例都使用 `@MainActor` 标记，确保在主线程上访问
2. 迁移管理器实现了 `Sendable` 协议，支持并发安全访问
3. 使用结构化并发（async/await）代替传统回调，提高代码清晰度和安全性

## 扩展点

### 1. 自定义迁移进度视图

您可以创建自定义迁移进度视图来替代默认的 `MigrationProgressView`：

```swift
struct MyCustomProgressView: View {
    @ObservedObject var migrationManager: MigrationManager
    
    var body: some View {
        // 自定义迁移界面...
    }
}
```

### 2. 自定义备份策略

可以通过修改 `MigrationConfiguration` 自定义备份行为：

```swift
let config = MigrationConfiguration(
    shouldCreateBackup: true,
    shouldRestoreFromBackupOnFailure: true,
    shouldRemoveOldBackups: true,
    maxBackupsToKeep: 5
)

let migrationManager = CoreDataMigrationManager(configuration: config)
```

### 3. 实现自定义资源管理

您可以扩展或继承 `CoreDataResourceManager` 以适应特定需求：

```swift
class MyCustomResourceManager: CoreDataResourceManager {
    // 自定义资源管理逻辑...
    
    override func findModelURL() -> URL? {
        // 自定义模型查找逻辑...
    }
}
```

## 贡献

欢迎对 CoreDataModule 迁移框架提供改进建议和贡献。请通过 Pull Request 或 Issue 提交您的想法。

## 许可

OnlySlide 项目的专有软件，未经许可不得分发。 