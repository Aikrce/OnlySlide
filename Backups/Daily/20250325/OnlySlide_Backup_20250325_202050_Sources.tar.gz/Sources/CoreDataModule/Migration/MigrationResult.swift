import Foundation

/// 迁移结果枚举，表示迁移操作的结果状态
public enum MigrationResult: Sendable {
    /// 迁移成功，包含迁移的对象计数
    case success(entitiesMigrated: Int)
    
    /// 迁移失败，包含错误信息
    case failure(Error)
    
    /// 迁移需要用户确认
    case requiresConfirmation(MigrationType)
    
    /// 迁移被用户取消
    case cancelled
    
    /// 迁移不需要（已经是最新版本）
    case notNeeded
    
    /// 是否为成功状态
    public var isSuccess: Bool {
        if case .success = self {
            return true
        }
        return false
    }
    
    /// 是否为失败状态
    public var isFailure: Bool {
        if case .failure = self {
            return true
        }
        return false
    }
    
    /// 是否需要用户确认
    public var requiresUserConfirmation: Bool {
        if case .requiresConfirmation = self {
            return true
        }
        return false
    }
    
    /// 获取迁移类型（如果适用）
    public var migrationType: MigrationType? {
        if case .requiresConfirmation(let type) = self {
            return type
        }
        return nil
    }
    
    /// 获取错误（如果适用）
    public var error: Error? {
        if case .failure(let error) = self {
            return error
        }
        return nil
    }
    
    /// 获取迁移的实体数量（如果适用）
    public var entitiesCount: Int? {
        if case .success(let count) = self {
            return count
        }
        return nil
    }
    
    /// 创建成功结果
    public static func createSuccess(entitiesMigrated: Int = 0) -> MigrationResult {
        return .success(entitiesMigrated: entitiesMigrated)
    }
    
    /// 创建失败结果
    public static func createFailure(_ error: Error) -> MigrationResult {
        return .failure(error)
    }
}

/// 迁移类型枚举
public enum MigrationType: String, Sendable {
    /// 轻量级迁移
    case lightweight = "lightweight"
    
    /// 标准迁移
    case standard = "standard"
    
    /// 重型迁移
    case heavyweight = "heavyweight"
    
    /// 是否为轻量级迁移
    public var isLightweight: Bool {
        return self == .lightweight
    }
    
    /// 是否为标准迁移
    public var isStandard: Bool {
        return self == .standard
    }
    
    /// 是否为重型迁移
    public var isHeavyweight: Bool {
        return self == .heavyweight
    }
    
    /// 获取友好描述
    public var description: String {
        switch self {
        case .lightweight:
            return "轻量级迁移"
        case .standard:
            return "标准迁移"
        case .heavyweight:
            return "重型迁移"
        }
    }
} 