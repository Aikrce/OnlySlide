import Foundation
import Combine

/// 负责报告迁移进度
@MainActor public final class MigrationProgressReporter: ObservableObject {
    // MARK: - Properties
    
    /// 当前状态
    @Published public private(set) var state: MigrationState = .notStarted
    
    /// 当前进度
    @Published public private(set) var progress: MigrationProgress?
    
    /// 当前错误
    @Published public private(set) var error: MigrationError?
    
    /// 是否正在迁移
    public var isInProgress: Bool {
        return state.isInProgress
    }
    
    /// 是否已完成
    public var isCompleted: Bool {
        return state.isCompleted
    }
    
    /// 是否失败
    public var isFailed: Bool {
        return state.isFailed
    }
    
    /// 进度百分比
    public var progressPercentage: Double {
        return progress?.percentage ?? 0
    }
    
    /// 进度分数
    public var progressFraction: Double {
        return progress?.fraction ?? 0
    }
    
    /// 当前步骤描述
    public var stepDescription: String {
        return progress?.description ?? "准备迁移..."
    }
    
    // MARK: - Initialization
    
    /// 初始化进度报告器
    public init() {}
    
    // MARK: - Public Methods
    
    /// 更新状态
    /// - Parameter state: 新状态
    public func updateState(_ state: MigrationState) {
        self.state = state
        
        // 更新相关属性
        if case .inProgress(let progress) = state {
            self.progress = progress
        } else if case .failed(let error) = state {
            self.error = error
        }
    }
    
    /// 更新进度
    /// - Parameter progress: 新进度
    public func updateProgress(_ progress: MigrationProgress) {
        self.progress = progress
        self.state = .inProgress(progress: progress)
    }
    
    /// 报告备份开始
    public func reportBackupStarted() {
        self.state = .backingUp
    }
    
    /// 报告恢复开始
    public func reportRestorationStarted() {
        self.state = .restoring
    }
    
    /// 报告准备开始
    public func reportPreparationStarted() {
        self.state = .preparing
    }
    
    /// 报告迁移开始
    public func reportMigrationStarted() {
        self.state = .preparing
    }
    
    /// 报告迁移完成
    /// - Parameter result: 迁移结果
    public func reportMigrationCompleted(result: MigrationResult) {
        self.state = .completed(result: result)
    }
    
    /// 报告迁移失败
    /// - Parameter error: 迁移错误
    public func reportMigrationFailed(error: MigrationError) {
        self.error = error
        self.state = .failed(error: error)
    }
    
    /// 报告迁移失败
    /// - Parameter error: 普通错误
    public func reportMigrationFailed(error: Error) {
        let migrationError = MigrationError.from(error)
        reportMigrationFailed(error: migrationError)
    }
    
    /// 重置状态
    public func reset() {
        self.state = .notStarted
        self.progress = nil
        self.error = nil
    }
} 